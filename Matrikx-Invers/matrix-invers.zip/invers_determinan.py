def invers_det(determinan):
  return 1/determinan