def cek_determinan(determinan):
  return determinan == 0

